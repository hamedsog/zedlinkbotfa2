﻿local function run(msg, matches)
local group = load_data('bot/group.json')	
local addgroup = group[tostring(msg.chat_id)]	
if matches[1] == 'help' and is_momod(msg) or is_owner(msg) and addgroup then
pm1 = [[◽️Help Bot Commands:
🔹!لینک ممنوع
🔹!ویرایش ممنوع
🔹!فروارد ممنوع
🔹!اسپم ممنوع
🔹!اینلاین ممنوع
🔹!فارسی ممنوع
🔹!انگلیسی ممنوع
🔹!فحش ممنوع
🔹!یوزرنیم ممنوع
🔹!تگ ممنوع
🔹!سرویس ممنوع
🔹!شماره ممنوع
🔹!گپ ممنوع
🔹!آهنگ ممنوع
🔹!ویس ممنوع
🔹!عکس ممنوع
🔹!گیف ممنوع
🔹!فیلم ممنوع
🔹!فایل ممنوع
🔹!استیکر ممنوع

]]
  tg.sendMessage(msg.chat_id_, 0, 1, pm1, 1, 'md')
end
end
	
return {
  patterns = {
  "^[/#!](help)$",
		
  },
  run = run
}
