local function اضافهgroup(msg)
local group = load_data('bot/group.json')
local groupa = group[tostring(msg.chat_id)]
if not groupa then
group[tostring(msg.chat_id)] = {
        group_type = 'SuperGroup',
		by = msg.from_id,
		moderators = {},
        set_owner = member_id ,
        settings = {
		  لینک_ممنوع = "no",
یوزرنیم_ممنوع = "no",
ویرایش_ممنوع = "no",
فروارد_ممنوع = "no",
رگباری_ممنوع = "no",
استیکر_ممنوع = "no",
فحش_ممنوع = "no",
شماره_ممنوع = "no",
روبات_ممنوع = "no",
انگلیسی_ممنوع = "no",
فارسی_ممنوع = "no",
سرویس_ممنوع = "no",			
تگ_ممنوع = "no",
اینلاین_ممنوع = "no",
lock_community = "no",				
گپ_ممنوع = "no",
mute_text = "no",				
عکس_ممنوع = "no",
فیلم_ممنوع = "no",
ویس_ممنوع = "no",
فایل_ممنوع = "no",
گیف_ممنوع = "no",
صدا_ممنوع = "no"
                  }
      }
      save_data(_config.group.data, group)
tg.sendMessage(msg.chat_id, msg.id_, 1, 'SuperGroup ➣➣ اضافه شد', 1)
else
tg.sendMessage(msg.chat_id, msg.id_, 1, 'SuperGroup ➣➣ اضافه شد', 1)
end
end
local function حذفgroup(msg)
local group = load_data('bot/group.json')
local groupa = group[tostring(msg.chat_id)]
if groupa then
group[tostring(msg.chat_id)] = nil
      save_data(_config.group.data, group)
tg.sendMessage(msg.chat_id, msg.id_, 1, 'SuperGroup ➣➣ حذف شد', 1)
else
tg.sendMessage(msg.chat_id, msg.id_, 1, 'SuperGroup ➣➣ حذف شد', 1)
end
end

local function run(msg, matches)
if matches[1] == 'اضافه' and is_sudo(msg) then
اضافهgroup(msg)
elseif matches[1] == 'حذف' and is_sudo(msg) then
حذفgroup(msg)
end
end
return {
  patterns = {
    "^[/#!](اضافه)$",
    "^[/#!](حذف)$",
 "^!!!edit:[/#!](اضافه)$",
    "^!!!edit:[/#!](حذف)$"
  },
  run = run
}
