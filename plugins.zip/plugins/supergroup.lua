﻿local function lock_group_links(msg, target)
local group = load_data('bot/group.json')
  local group_link_lock = group[tostring(target)]['settings']['لینک_ممنوع']
  if group_link_lock == 'yes' then
    pm = '<b>Link</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['لینک_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>Link</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_username(msg, target)
local group = load_data('bot/group.json')
  local group_username_lock = group[tostring(target)]['settings']['یوزرنیم_ممنوع']
  if group_username_lock == 'yes' then
    pm = '<b>username</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['یوزرنیم_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>username</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_fosh(msg, target)
local group = load_data('bot/group.json')
  local group_fosh_lock = group[tostring(target)]['settings']['فحش_ممنوع']
  if group_fosh_lock == 'yes' then
    pm = '<b>Fosh</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['فحش_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>Fosh</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end

local function lock_group_contact(msg, target)
local group = load_data('bot/group.json')
  local group_contact_lock = group[tostring(target)]['settings']['شماره_ممنوع']
  if group_contact_lock == 'yes' then
    pm = '<b>Contact</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['شماره_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>Contact</b> <b>➣➣</b> <b>lock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end

local function lock_group_game(msg, target)
local group = load_data('bot/group.json')
  local group_game_lock = group[tostring(target)]['settings']['lock_game']
  if group_game_lock == 'yes' then
    pm = '<b>Game</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['lock_game'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>Game</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end

local function lock_group_bot(msg, target)
local group = load_data('bot/group.json')
  local group_bot_lock = group[tostring(target)]['settings']['روبات_ممنوع']
  if group_bot_lock == 'yes' then
    pm = '<b>Bot api</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['روبات_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>Bot api</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_edit(msg, target)
local group = load_data('bot/group.json')
  local group_edit_lock = group[tostring(target)]['settings']['ویرایش_ممنوع']
  if group_edit_lock == 'yes' then
    pm = '<b>Edite</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['ویرایش_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>Edite</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_fwd(msg, target)
local group = load_data('bot/group.json')
  local group_fwd_lock = group[tostring(target)]['settings']['فروارد_ممنوع']
  if group_fwd_lock == 'yes' then
    pm = '<b>Fwd</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['فروارد_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>Fwd</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_spam(msg, target)
local group = load_data('bot/group.json')
  local group_spam_lock = group[tostring(target)]['settings']['رگباری_ممنوع']
  if group_spam_lock == 'yes' then
    pm = '<b>Spem</b> <b>➣➣</b> <b>lock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['رگباری_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm= '<b>Spem</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_sticker(msg, target)
local group = load_data('bot/group.json')
  local group_sticker_lock = group[tostring(target)]['settings']['استیکر_ممنوع']
  if group_sticker_lock == 'yes' then
    pm = '<b>sticker</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['استیکر_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>sticker</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_english(msg, target)
local group = load_data('bot/group.json')
  local group_english_lock = group[tostring(target)]['settings']['انگلیسی_ممنوع']
  if group_english_lock == 'yes' then
    pm = '<b>english</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['انگلیسی_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>english</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_persian(msg, target)
local group = load_data('bot/group.json')
  local group_persian_lock = group[tostring(target)]['settings']['فارسی_ممنوع']
  if group_persian_lock == 'yes' then
    pm = '<b>persian</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['فارسی_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>persian</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_tgservice(msg, target)
local group = load_data('bot/group.json')
  local group_tgservice_lock = group[tostring(target)]['settings']['سرویس_ممنوع']
  if group_tgservice_lock == 'yes' then
    pm = '<b>tgservice</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['سرویس_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>tgservice</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_tag(msg, target)
local group = load_data('bot/group.json')
  local group_tag_lock = group[tostring(target)]['settings']['تگ_ممنوع']
  if group_tag_lock == 'yes' then
    pm = '<b>tag</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['تگ_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>tag</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_inline(msg, target)
local group = load_data('bot/group.json')
  local group_inline_lock = group[tostring(target)]['settings']['اینلاین_ممنوع']
  if group_inline_lock == 'yes' then
    pm = '<b>Inline</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['اینلاین_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>Inline</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function lock_group_community(msg, target)
local group = load_data('bot/group.json')
  local group_community_lock = group[tostring(target)]['settings']['lock_community']
  if group_community_lock == 'yes' then
    pm = '<b>Community</b> <b>➣➣</b> <b>lock</b>'
  tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
else
    group[tostring(target)]['settings']['lock_community'] = 'yes'
    save_data(_config.group.data, group)
    pm = '<b>Community</b> <b>➣➣</b> <b>locked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
------------------
local function unlock_group_links(msg, target)
local group = load_data('bot/group.json')
  local group_link_lock = group[tostring(target)]['settings']['لینک_ممنوع']
  if group_link_lock == 'no' then
    pm = '<b>Link</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['لینک_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Link</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_username(msg, target)
local group = load_data('bot/group.json')
  local group_username_lock = group[tostring(target)]['settings']['یوزرنیم_ممنوع']
  if group_username_lock == 'no' then
    pm = '<b>username</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['یوزرنیم_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>username</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_fosh(msg, target)
local group = load_data('bot/group.json')
  local group_fosh_lock = group[tostring(target)]['settings']['فحش_ممنوع']
  if group_fosh_lock == 'no' then
    pm = '<b>Fosh</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['فحش_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Fosh</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end

local function unlock_group_contact(msg, target)
local group = load_data('bot/group.json')
  local group_contact_lock = group[tostring(target)]['settings']['شماره_ممنوع']
  if group_contact_lock == 'no' then
    pm = '<b>Contact</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['شماره_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Contact</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end

local function unlock_group_game(msg, target)
local group = load_data('bot/group.json')
  local group_game_lock = group[tostring(target)]['settings']['lock_game']
  if group_game_lock == 'no' then
    pm = '<b>Game</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['lock_game'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Game</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end

local function unlock_group_bot(msg, target)
local group = load_data('bot/group.json')
  local group_bot_lock = group[tostring(target)]['settings']['روبات_ممنوع']
  if group_bot_lock == 'no' then
    pm = '<b>Bot api</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['روبات_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Bot api</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_edit(msg, target)
local group = load_data('bot/group.json')
  local group_edit_lock = group[tostring(target)]['settings']['ویرایش_ممنوع']
  if group_edit_lock == 'no' then
    pm = '<b>Edite</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['ویرایش_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Edite</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_fwd(msg, target)
local group = load_data('bot/group.json')
  local group_fwd_lock = group[tostring(target)]['settings']['فروارد_ممنوع']
  if group_fwd_lock == 'no' then
    pm = '<b>Fwd</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['فروارد_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Fwd</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_spam(msg, target)
local group = load_data('bot/group.json')
  local group_spam_lock = group[tostring(target)]['settings']['رگباری_ممنوع']
  if group_spam_lock == 'no' then
    pm = '<b>Spam</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['رگباری_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Spam</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_sticker(msg, target)
local group = load_data('bot/group.json')
  local group_sticker_lock = group[tostring(target)]['settings']['استیکر_ممنوع']
  if group_sticker_lock == 'no' then
    pm = '<b>sticker</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['استیکر_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>sticker</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_english(msg, target)
local group = load_data('bot/group.json')
  local group_english_lock = group[tostring(target)]['settings']['انگلیسی_ممنوع']
  if group_english_lock == 'no' then
    pm = '<b>english</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['انگلیسی_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>english</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_persian(msg, target)
local group = load_data('bot/group.json')
  local group_persian_lock = group[tostring(target)]['settings']['فارسی_ممنوع']
  if group_persian_lock == 'no' then
    pm = '<b>persian</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['فارسی_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>persian</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_tgservice(msg, target)
local group = load_data('bot/group.json')
  local group_tgservice_lock = group[tostring(target)]['settings']['سرویس_ممنوع']
  if group_tgservice_lock == 'no' then
    pm = '<b>tgservice</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['سرویس_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>tgservice</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_tag(msg, target)
local group = load_data('bot/group.json')
  local group_tag_lock = group[tostring(target)]['settings']['تگ_ممنوع']
  if group_tag_lock == 'no' then
    pm = '<b>tag</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['تگ_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>tag</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_inline(msg, target)
local group = load_data('bot/group.json')
  local group_inline_lock = group[tostring(target)]['settings']['اینلاین_ممنوع']
  if group_inline_lock == 'no' then
    pm = '<b>Inline</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['اینلاین_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Inline</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unlock_group_community(msg, target)
local group = load_data('bot/group.json')
  local group_community_lock = group[tostring(target)]['settings']['lock_community']
  if group_community_lock == 'no' then
    pm = '<b>Community</b> <b>➣➣</b> <b>unlock</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['lock_community'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Community</b> <b>➣➣</b> <b>unlocked</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
----------

local function گپ_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local گپ_ممنوع = group[tostring(target)]['settings']['گپ_ممنوع']
  if گپ_ممنوع  == 'yes' then
    pm = '<b>All</b> ➣➣ <b>mute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['گپ_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm= '<b>All</b> ➣➣ <b>muted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unگپ_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local گپ_ممنوع = group[tostring(target)]['settings']['گپ_ممنوع']
  if گپ_ممنوع  == 'no' then
    pm = '<b>All</b> ➣➣ <b>unmute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['گپ_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>All</b> ➣➣ <b>unmuted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function mute_text_group(msg, target)
local group = load_data('bot/group.json')
  local mute_text = group[tostring(target)]['settings']['mute_text']
  if mute_text  == 'yes' then
    pm = '<b>Text</b> ➣➣ <b>mute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['mute_text'] = 'yes'
    save_data(_config.group.data, group)
    pm= '<b>Text</b> ➣➣ <b>muted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unmute_text_group(msg, target)
local group = load_data('bot/group.json')
  local mute_text = group[tostring(target)]['settings']['mute_text']
  if mute_text  == 'no' then
    pm = '<b>Text</b> ➣➣ <b>unmute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['mute_text'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Text</b> ➣➣ <b>unmuted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function عکس_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local گپ_ممنوع = group[tostring(target)]['settings']['عکس_ممنوع']
  if گپ_ممنوع  == 'yes' then
    pm = '<b>Photo</b> ➣➣ <b>unmute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['عکس_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm= '<b>Photo</b> ➣➣ <b>muted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unعکس_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local گپ_ممنوع = group[tostring(target)]['settings']['عکس_ممنوع']
  if گپ_ممنوع  == 'no' then
    pm = '<b>Photo</b> ➣➣ <b>unmute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['عکس_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Photo</b> ➣➣ <b>unmuted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function فیلم_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local فیلم_ممنوع = group[tostring(target)]['settings']['فیلم_ممنوع']
  if فیلم_ممنوع  == 'yes' then
    pm = '<b>Video</b> ➣➣ <b>mute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['فیلم_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm= '<b>Video</b> ➣➣ <b>muted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unفیلم_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local فیلم_ممنوع = group[tostring(target)]['settings']['فیلم_ممنوع']
  if فیلم_ممنوع  == 'no' then
    pm = '<b>Video</b> ➣➣ <b>unmute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['فیلم_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Video</b> ➣➣ <b>unmuted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function گیف_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local گیف_ممنوع = group[tostring(target)]['settings']['گیف_ممنوع']
  if گیف_ممنوع  == 'yes' then
    pm = '<b>Gifs</b> ➣➣ <b>mute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['گیف_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm= '<b>Gifs</b> ➣➣ <b>muted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unگیف_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local گیف_ممنوع = group[tostring(target)]['settings']['گیف_ممنوع']
  if گیف_ممنوع  == 'no' then
    pm = '<b>Gifs</b> ➣➣ <b>unmute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['گیف_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Gifs</b> ➣➣ <b>unmuted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function ویس_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local ویس_ممنوع = group[tostring(target)]['settings']['ویس_ممنوع']
  if ویس_ممنوع  == 'yes' then
    pm = '<b>Voice</b> ➣➣ <b>mute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['ویس_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm= '<b>Voice</b> ➣➣ <b>muted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unویس_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local ویس_ممنوع = group[tostring(target)]['settings']['ویس_ممنوع']
  if ویس_ممنوع  == 'no' then
    pm = '<b>Voice</b> ➣➣ <b>unmute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['ویس_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Voice</b> ➣➣ <b>unmuted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function صدا_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local صدا_ممنوع = group[tostring(target)]['settings']['صدا_ممنوع']
  if صدا_ممنوع  == 'yes' then
    pm = '<b>Audio</b> ➣➣ <b>mute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['صدا_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm= '<b>Audio</b> ➣➣ <b>muted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unصدا_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local صدا_ممنوع = group[tostring(target)]['settings']['صدا_ممنوع']
  if صدا_ممنوع  == 'no' then
    pm = '<b>Audio</b> ➣➣ <b>unmute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['صدا_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Audio</b> ➣➣ <b>unmuted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function فایل_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local فایل_ممنوع = group[tostring(target)]['settings']['فایل_ممنوع']
  if فایل_ممنوع  == 'yes' then
    pm = '<b>Documents</b> ➣➣ <b>mute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['فایل_ممنوع'] = 'yes'
    save_data(_config.group.data, group)
    pm= '<b>Documents</b> ➣➣ <b>muted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
end
local function unفایل_ممنوع_group(msg, target)
local group = load_data('bot/group.json')
  local فایل_ممنوع = group[tostring(target)]['settings']['فایل_ممنوع']
  if فایل_ممنوع  == 'no' then
    pm = '<b>Documents</b> ➣➣ <b>unmute</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  else
    group[tostring(target)]['settings']['فایل_ممنوع'] = 'no'
    save_data(_config.group.data, group)
    pm= '<b>Documents</b> ➣➣ <b>unmuted</b>'
tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
  end
 end

local function group_settings(msg, target)
local group = load_data('bot/group.json')
pm = '<b>⚙️ SuperGroup settings:</b>'
--pm = pm..'\n <code>💈💈💈💈💈💈💈💈💈</code>'
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Links</b> <code>»</code> '..group[tostring(target)]['settings']['لینک_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>User</b> <code>»</code> '..group[tostring(target)]['settings']['یوزرنیم_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Edit</b> <code>»</code> '..group[tostring(target)]['settings']['ویرایش_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Fwd</b> <code>»</code> '..group[tostring(target)]['settings']['فروارد_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Spam</b> <code>»</code> '..group[tostring(target)]['settings']['رگباری_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Sticker</b> <code>»</code>'..group[tostring(target)]['settings']['استیکر_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>fosh</b> <code>»</code>'..group[tostring(target)]['settings']['فحش_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>contact</b> <code>»</code>'..group[tostring(target)]['settings']['شماره_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>bot</b> <code>»</code>'..group[tostring(target)]['settings']['روبات_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Eng</b> <code>»</code> '..group[tostring(target)]['settings']['انگلیسی_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Far</b> <code>»</code> '..group[tostring(target)]['settings']['فارسی_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Tg</b> <code>»</code> '..group[tostring(target)]['settings']['سرویس_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Tag</b> <code>»</code> '..group[tostring(target)]['settings']['تگ_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Inline</b> <code>»</code> '..group[tostring(target)]['settings']['اینلاین_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>Lock</b> <code>➣</code> <b>Commun</b> <code>»</code> '..group[tostring(target)]['settings']['lock_community']..''
pm = pm..'\n🏮 <code>➣</code> <b>mute</b> <code>➣</code> <b>All</b> <code>»</code> '..group[tostring(target)]['settings']['گپ_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>mute</b> <code>➣</code> <b>Text</b> <code>»</code> '..group[tostring(target)]['settings']['mute_text']..''
pm = pm..'\n🏮 <code>➣</code> <b>mute</b> <code>➣</code> <b>Photo</b> <code>»</code> '..group[tostring(target)]['settings']['عکس_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>mute</b> <code>➣</code> <b>Video</b> <code>»</code> '..group[tostring(target)]['settings']['فیلم_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>mute</b> <code>➣</code> <b>Voice</b> <code>»</code> '..group[tostring(target)]['settings']['ویس_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>mute</b> <code>➣</code> <b>Doc</b> <code>»</code> '..group[tostring(target)]['settings']['فایل_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>mute</b> <code>➣</code> <b>Audio</b> <code>»</code> '..group[tostring(target)]['settings']['صدا_ممنوع']..''
pm = pm..'\n🏮 <code>➣</code> <b>mute</b> <code>➣</code> <b>Gif</b> <code>»</code> '..group[tostring(target)]['settings']['گیف_ممنوع']..''
--pm = '<code>→→→→→→→→→→→→</code>'
pm = pm..'\n'

tg.sendMessage(msg.chat_id_, 0, 1, pm, 1, 'html')
end
local function run(msg, matches)
local group = load_data('bot/group.json')
local addgroup = group[tostring(msg.chat_id)]
if addgroup and is_momod(msg) then
if matches[1] == 'settings'  then
group_settings(msg, msg.chat_id)
elseif matches[1] == 'lock' then
if matches[2] == 'links' then
lock_group_links(msg, msg.chat_id)
elseif matches[2] == 'edit' then
lock_group_edit(msg, msg.chat_id)
elseif matches[2] == 'fwd' then
lock_group_fwd(msg, msg.chat_id)
elseif matches[2] == 'bot' then
lock_group_bot(msg, msg.chat_id)
elseif matches[2] == 'fosh' then
lock_group_fosh(msg, msg.chat_id)
elseif matches[2] == 'contact' then
lock_group_contact(msg, msg.chat_id)
elseif matches[2] == 'game' then
lock_group_game(msg, msg.chat_id)
elseif matches[2] == 'username' then
lock_group_username(msg, msg.chat_id)
elseif matches[2] == 'spam' then
lock_group_spam(msg, msg.chat_id)
elseif matches[2] == 'sticker' then
lock_group_sticker(msg, msg.chat_id)
elseif matches[2] == 'english' then
lock_group_english(msg, msg.chat_id)
elseif matches[2] == 'persian' then
lock_group_persian(msg, msg.chat_id)
elseif matches[2] == 'tgservice' then
lock_group_tgservice(msg, msg.chat_id)
elseif matches[2] == 'tag' then
lock_group_tag(msg, msg.chat_id)
elseif matches[2] == 'inline' then
lock_group_inline(msg, msg.chat_id)
elseif matches[2] == 'community' then
lock_group_community(msg, msg.chat_id)
end
elseif matches[1] == 'unlock' then
if matches[2] == 'links' then
unlock_group_links(msg, msg.chat_id,group )
elseif matches[2] == 'edit' then
unlock_group_edit(msg, msg.chat_id)
elseif matches[2] == 'fwd' then
unlock_group_fwd(msg, msg.chat_id)
elseif matches[2] == 'username' then
unlock_group_username(msg, msg.chat_id)
elseif matches[2] == 'bot' then
unlock_group_bot(msg, msg.chat_id)
elseif matches[2] == 'fosh' then
unlock_group_fosh(msg, msg.chat_id)
elseif matches[2] == 'contact' then
unlock_group_contact(msg, msg.chat_id)
elseif matches[2] == 'game' then
unlock_group_game(msg, msg.chat_id)
elseif matches[2] == 'spam' then
unlock_group_spam(msg, msg.chat_id)
elseif matches[2] == 'sticker' then
unlock_group_sticker(msg, msg.chat_id)
elseif matches[2] == 'english' then
unlock_group_english(msg, msg.chat_id)
elseif matches[2] == 'persian' then
unlock_group_persian(msg, msg.chat_id)
elseif matches[2] == 'tag' then
unlock_group_tag(msg, msg.chat_id)
elseif matches[2] == 'tgservice' then
unlock_group_tgservice(msg, msg.chat_id)
elseif matches[2] == 'inline' then
unlock_group_inline(msg, msg.chat_id,group )
elseif matches[2] == 'community' then
unlock_group_community(msg, msg.chat_id)
end
elseif matches[1] == 'mute' or matches[1] == 'lock' then
if matches[2] == 'all' then
گپ_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'text' then
mute_text_group(msg, msg.chat_id)
elseif matches[2] == 'photo' then
عکس_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'document' then
فایل_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'gif' then
گیف_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'audio' then
صدا_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'voice' then
ویس_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'video' then
فیلم_ممنوع_group(msg, msg.chat_id)
end
elseif matches[1] == 'unmute' or matches[1] == 'unlock' then
if matches[2] == 'all' then
unگپ_ممنوع_group(msg, msg.chat_id,group )
elseif matches[2] == 'text' then
unmute_text_group(msg, msg.chat_id)
elseif matches[2] == 'photo' then
unعکس_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'document' then
unفایل_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'gif' then
unگیف_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'audio' then
unصدا_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'voice' then
unویس_ممنوع_group(msg, msg.chat_id)
elseif matches[2] == 'video' then
unفیلم_ممنوع_group(msg, msg.chat_id)
end
end
end
end
---------------

return {
  patterns = {
    "^[/#!](lock) (.*)$",
    "^[/#!](unlock) (.*)$",
    "^[/#!](mute) (.*)$",
    "^[/#!](unmute) (.*)$",
    "^[/#!](settings)$",
"^!!!edit:[/#!](lock) (.*)$",
"^!!!edit:[/#!](unlock) (.*)$",
"^!!!edit:[/#!](mute) (.*)$",
"^!!!edit:[/#!](unmute) (.*)$",
"^!!!edit:[/#!](settings)$"
  },
  run = run
}




