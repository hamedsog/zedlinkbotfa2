do local _ = {
  enabled_plugins = {
    "addrem",
    "bc",
    "supergroup",
    "msg_checks",
    "pin",
    "owner",
    "online",
    "plugins",
    "admin",
    "id",
    "del",
    "clean",
    "expiretime",
    "filter",
    "setlink",
    "setrules",
    "help",
    "leave",
    "lock_bots",
    "me"
  },
  group = {
    data = "bot/group.json"
  },
  robot = {
    987654321,
    0
  },
  sudo_users = {
    13456789,
    0
  }
}
return _
end
